﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[AttributeUsage(AttributeTargets.Class |
                AttributeTargets.Method,
    AllowMultiple = true)]

public class SoftUniAttribute : Attribute
{
    private string name;
    public SoftUniAttribute(string name)
    {
        this.Name = name;
    }

    public string Name
    {
        get { return this.name; }
        private set { this.name = value; }
    }
}

