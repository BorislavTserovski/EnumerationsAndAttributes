﻿using System;

public class InputReader
{
    internal string ReadLine() => Console.ReadLine();
}